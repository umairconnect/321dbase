@extends('layouts.app', ['title' => 'Dashboard'])

@section('content')
<div class="d-flex flex-column-fluid">
    <div class="container-fluid mx-lg-5">
        <div class="row mt-0 mt-lg-3">
            <!-- @TODO -->
            <div class="col-lg-12">
                <h1>Coming Soon!</h1>
            </div>
        </div>
    </div>
</div>
@endsection