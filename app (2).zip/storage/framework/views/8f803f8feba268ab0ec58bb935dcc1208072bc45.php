<?php $__env->startPush('js'); ?>
<script>
    // Bootstrap Notify function
    function bootstrapNotify(notifyType, notifyText) {
        var content = {};

        content.message = notifyText;

        var notify = $.notify(content, {
            type: notifyType,
            allow_dismiss: true,
            spacing: 10,
            timer: 2000,
            placement: {
                from: 'top',
                align: 'right'
            },
            offset: {
                x: 30,
                y: 30
            },
            delay: 1000,
            z_index: 10000,
            animate: {
                enter: 'animate__animated animate__bounce',
                exit: 'animate__animated animate__bounce'
            }
        });
    }

    // Success Notify
    <?php if($message = Session::get('success')): ?>
        bootstrapNotify('success', '<?php echo e($message); ?>')
    <?php endif; ?>

    // Error Notify
    <?php if($message = Session::get('error')): ?>
        bootstrapNotify('danger', '<?php echo e($message); ?>')
    <?php endif; ?>

    // Warning Notify
    <?php if($message = Session::get('warning')): ?>
        bootstrapNotify('warning', '<?php echo e($message); ?>')
    <?php endif; ?>

    // Info Notify
    <?php if($message = Session::get('info')): ?>
        bootstrapNotify('info', '<?php echo e($message); ?>')
    <?php endif; ?>

    // Primary Notify
    <?php if($message = Session::get('primary')): ?>
        bootstrapNotify('primary', '<?php echo e($message); ?>')
    <?php endif; ?>

    // Dark Notify
    <?php if($message = Session::get('dark')): ?>
        bootstrapNotify('dark', '<?php echo e($message); ?>')
    <?php endif; ?>
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/dbase/public_html/resources/views/layouts/components/notify.blade.php ENDPATH**/ ?>