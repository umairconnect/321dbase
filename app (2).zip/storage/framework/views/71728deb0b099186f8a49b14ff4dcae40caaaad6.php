

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-column-fluid">
    <div class="container-fluid mx-lg-5">
        <div class="row mt-0 mt-lg-3">
            <!-- @TODO  -->
            <div class="col-lg-12">
                <h1>Coming Soon!</h1>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', ['title' => 'Dashboard'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\RG\Brazil\Marcos\New Work\wi5\resources\views/groupadmin/dashboard/index.blade.php ENDPATH**/ ?>