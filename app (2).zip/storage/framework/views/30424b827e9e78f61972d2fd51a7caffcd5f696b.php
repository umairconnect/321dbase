<script>
    var globalVars = {
        tdLanguage: {
            search: 'Search',
            sZeroRecords: 'No results found',
            lengthMenu: 'Rows per page _MENU_',
            info: '_PAGE_-_PAGES_ of _TOTAL_',
            sInfo: '_PAGE_-_PAGES_ of _TOTAL_',
            sInfoEmpty: '0-0 of 0',
            sInfoFiltered: '(filtered from _MAX_ total rows)'
        },

        messages: {
            commonError: 'Something went to wrong. Try again later.',
            importing: 'Importing...'
        }
    };
</script><?php /**PATH /home/dbase/public_html/resources/views/layouts/globals/js_global_vars.blade.php ENDPATH**/ ?>