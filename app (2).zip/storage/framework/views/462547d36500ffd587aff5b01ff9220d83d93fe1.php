

<?php $__env->startSection('content'); ?>
<div class="login-form">
    <div class="text-center mb-5">
        <img src="<?php echo e(asset('images/logo.png')); ?>" />
        <h5>LOGIN TO Wi5 ADMIN</h5>
    </div>
    <?php if($errors->has('login_failed')): ?>
    <div class="alert alert-danger d-flex alert-dismissible fade show">
        <?php echo e($errors->first('login_failed')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"
            aria-label="Close"></button>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('masteradmin.login')); ?>" method="POST" id="login-form">
        <?php echo csrf_field(); ?>
        <div class="login-form-group">
            <label for="login">Email or username</label>
            <input type="text" name="login" id="login" class="login-form-control" value="<?php echo e(old('login')); ?>" />
            <?php if($errors->has('login')): ?>
            <span class="text-danger">Please enter email or password.</span>
            <?php endif; ?>
        </div>
        <div class="login-form-group mt-4">
            <label for="password">Password</label>
            <input type="password" name="password" id="password" class="login-form-control" value="<?php echo e(old('password')); ?>" />
            <?php if($errors->has('password')): ?>
            <span class="text-danger">Please enter password.</span>
            <?php endif; ?>
        </div>
        <div class="pt-4 d-flex justify-content-between">
            <label class="color-checkbox primary-color">Remember me
                <input type="checkbox" name="remember" />
                <span class="checkmark"></span>
            </label>
            <a href="">Forgot password?</a>
        </div>
        <button type="submit" class="login-btn mt-5">Log In</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('auth.layout', ['title' => 'Login to Wi5 Admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\RG\Brazil\Marcos\New Work\wi5\resources\views/auth/masteradmin_login.blade.php ENDPATH**/ ?>